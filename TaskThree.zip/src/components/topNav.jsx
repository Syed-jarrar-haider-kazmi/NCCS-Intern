import React from "react";
import "./css/styles.css";

function TopNav() {
  return (
    <div className="mainSection">
      <div>
        <ul className="nav-list">
          <li className="nav-li">
            <a href="Host">Host</a>
          </li>
          <li className="nav-li">
            <a href="Manufacturer">Manufacturer</a>
          </li>
          <li className="nav-li">
            <a href="OS">OS</a>
          </li>
        </ul>
        <div className="li-separator"></div>
      </div>
      {/* <button className="clickable">
        <p className="button-text">Hosts</p>
      </button>
      <button className="clickable">
        <p className="button-text">Manufacturer</p>
      </button>
      <button className="clickable">
        <p className="button-text">OS</p>
      </button>
      <br /> */}
      <select className="Filter" name="filter" id="filter">
        <option value="Filter">Filter</option>
        <option value="Host">Host</option>
        <option value="Manufacturer">Manufacturer</option>
        <option value="OS">OS</option>
      </select>

      <input
        className="Search"
        type="text"
        name="search"
        id="search"
        placeholder="Search Hosts"
      />
    </div>
  );
}

export default TopNav;
