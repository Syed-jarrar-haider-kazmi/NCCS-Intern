import React from 'react';
import "./css/scanDetails.css"


function ScanDetails(props) {
    return (<div>
        
        <p className="scan-heading">Scan Details</p>
        <div className="scan-separator"></div>

        <ul class="scan-list">
        <li><b className="scan-bold">Policy</b>{props.details.Policy}</li>
        <li><b className="scan-bold">Status</b>{props.details.Status}</li>
        <li><b className="scan-bold">Severity Base</b>{props.details.Severity_Base} </li>
        <li><b className="scan-bold">Scanner</b>{props.details.Scanner}</li>
        <li><b className="scan-bold">Start</b>{props.details.Start}</li>
        <li><b className="scan-bold">End</b>{props.details.End}</li>
        <li><b className="scan-bold">Elapsed</b>{props.details.Elapsed}</li>
        </ul>
    </div>  );
}

export default ScanDetails;