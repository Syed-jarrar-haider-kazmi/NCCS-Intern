import React from "react";
import TopNav from "./topNav";
import ScanDetails from "./scanDetails";
import "./css/styles.css";



function MainPage() {
  return (
    <div>
      <div class="header"></div>
      <div class="container">
        <div class="sides"></div>
        <div class="main-Right">
          <header>
            <div>
              <h2 className="sheading">My Basic Network Scan</h2>
            </div>
            {/* <div>B</div> */}
          </header>
          <TopNav></TopNav>
          <div className="middle">
            <div className="tables">
              <div className="data">
                <div className="data-head">Serverity</div>
                <div className="data-head">IP</div>
                <div className="data-head">OS</div>
                {renderTableData()}
              </div>
            </div>
            <ScanDetails details={sendScanDetails()}></ScanDetails>
          </div>
        </div>
      </div>
    </div>
  );
  function sendScanDetails() {
    let scanDetails = {
      Policy: "Basic Network Scan",
      Status: "Completed",
      Severity_Base: "CVSS v3.0",
      Scanner: "Local Scanner",
      Start: "Today at 11:26AM",
      End: "Today at 11:33AM",
      Elapsed: "6 minutes",
    };
    return scanDetails;
  }
}
function renderTableData() {
  const datas = [
    {
      serverty: "high",
      ip: "192.168.100.21",
      os: "Window 11",
    },
    {
      serverty: "low",
      ip: "192.168.100.22",
      os: "Linux",
    },
    {
      serverty: "medium",
      ip: "192.168.100.23",
      os: "Ubuntu",
    },
    {
    
      serverty: "high",
      ip: "192.168.100.21",
      os: "Window 11",
     
    },
    {
      serverty: "low",
      ip: "192.168.100.22",
      os: "Linux",
    },
    {
      serverty: "medium",
      ip: "192.168.100.23",
      os: "Ubuntu",
    },
    {
      serverty: "high",
      ip: "192.168.100.21",
      os: "Window 11",
    },
    {
      serverty: "low",
      ip: "192.168.100.22",
      os: "Linux",
    },
    {
      serverty: "medium",
      ip: "192.168.100.23",
      os: "Ubuntu",
    },
    {
      serverty: "high",
      ip: "192.168.100.21",
      os: "Window 11",
    },
    {
      serverty: "low",
      ip: "192.168.100.22",
      os: "Linux",
    },
  ];
  return datas.map((data, index) => {
    const {  serverty,os, ip } = data; //destructuring
    return (
      <React.Fragment>
          <p className="data" >{serverty}</p>
       
          <p className="data">{ip}</p>
     
          <p className="data">{os}</p>
      
      </React.Fragment>
    );
  });
}

export default MainPage;
