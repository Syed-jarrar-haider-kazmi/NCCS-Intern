import React, { Component } from "react";
import "./collapse.css";
import Collapsible from "../collapsible";
import InfoGather from "../infoGathering";
class Improve extends Component {
  state = {
    row: 0,
    Name: "Syed",
    netaddress: "192.168.100.1/24",
    portno: "192.168.100.22",
  };

  datas = {
    network: [
      {
        _id: 1,
        serverty: "high",
        ip: "192.168.100.21",
        os: "Window 11",
        manufacture: "Microsoft",
      },
      {
        _id: 2,
        serverty: "low",
        ip: "192.168.100.22",
        os: "Linux",
        manufacture: "Open Source",
      },
      {
        _id: 3,
        serverty: "medium",
        ip: "192.168.100.23",
        os: "Ubuntu",
        manufacture: "Canonical",
      },
      {
        _id: 4,
        serverty: "high",
        ip: "192.168.100.21",
        os: "Window 11",
        manufacture: "Microsoft",
      },
      {
        _id: 5,
        serverty: "low",
        ip: "192.168.100.22",
        os: "Linux",
        manufacture: "Open Source",
      },
      {
        _id: 6,
        serverty: "medium",
        ip: "192.168.100.23",
        os: "Ubuntu",
        manufacture: "Canonical",
      },
      {
        _id: 1,
        serverty: "high",
        ip: "192.168.100.21",
        os: "Window 11",
        manufacture: "Microsoft",
      },
      {
        _id: 2,
        serverty: "low",
        ip: "192.168.100.22",
        os: "Linux",
        manufacture: "Open Source",
      },
      {
        _id: 6,
        serverty: "medium",
        ip: "192.168.100.23",
        os: "Ubuntu",
        manufacture: "Canonical",
      },
      {
        _id: 1,
        serverty: "high",
        ip: "192.168.100.21",
        os: "Window 11",
        manufacture: "Microsoft",
      },
      {
        _id: 2,
        serverty: "low",
        ip: "192.168.100.22",
        os: "Linux",
        manufacture: "Open Source",
      },
    ],
  };
  tabel2 = {
    port: [
      {
        _id: 1,
        serverity: "555",
        cvNo: "29",
        portno: "607",
        services: "RFC 1034",
        version: "http",
      },
      {
        _id: 2,
        serverity: "555",
        cvNo: "09",
        portno: "667",
        services: "login",
        version: "dns",
      },
      {
        _id: 3,
        serverity: "123",
        cvNo: "19",
        portno: "513",
        services: "ic",
        version: "TCP",
      },
      {
        _id: 1,
        serverty: "high",
        ip: "192.168.100.21",
        os: "Window 11",
        manufacture: "Microsoft",
      },
      {
        _id: 2,
        serverty: "low",
        ip: "192.168.100.22",
        os: "Linux",
        manufacture: "Open Source",
      },
      {
        _id: 3,
        serverty: "medium",
        ip: "192.168.100.23",
        os: "Ubuntu",
        manufacture: "Canonical",
      },
    ],
  };
  tabel2 = {
    port: [
      {
        _id: 1,
        serverity: "555",
        cvNo: "29",
        portno: "607",
        services: "RFC 1034",
        version: "http",
      },
      {
        _id: 2,
        serverity: "555",
        cvNo: "09",
        portno: "667",
        services: "login",
        version: "dns",
      },
      {
        _id: 3,
        serverity: "123",
        cvNo: "19",
        portno: "513",
        services: "ic",
        version: "TCP",
      },
      {
        _id: 1,
        serverity: "555",
        cvNo: "29",
        portno: "607",
        services: "RFC 1034",
        version: "http",
      },
      {
        _id: 2,
        serverity: "555",
        cvNo: "09",
        portno: "667",
        services: "login",
        version: "dns",
      },
      {
        _id: 3,
        serverity: "123",
        cvNo: "19",
        portno: "513",
        services: "ic",
        version: "TCP",
      },
      {
        _id: 1,
        serverity: "555",
        cvNo: "29",
        portno: "607",
        services: "RFC 1034",
        version: "http",
      },
      {
        _id: 2,
        serverity: "555",
        cvNo: "09",
        portno: "667",
        services: "login",
        version: "dns",
      },
      {
        _id: 3,
        serverity: "123",
        cvNo: "19",
        portno: "513",
        services: "ic",
        version: "TCP",
      },
    ],
  };
  panes = [
    "Information Gathering",
    "Network Attack",
    "Network Generation",
    "Vulnerability Test",
    "Report Generation",
    "Supports",
  ];
  render() {
    return (
      <div class="wrapper">
        <div class="main Slider">
          <p className="title">scydes</p>
          <ul className="navs">
            {this.panes.map((tag) => (
              <li className="nav-items" key={tag}>
                {tag}
              </li>
            ))}
          </ul>
          <p className="footer">copyright 2021, SCYDES</p>
        </div>
        <div class="main-Right">
          <div className="g-1 ">
            <p className="p-a">Network Address: {this.state.netaddress}</p>
            <p className="p-b p-b-c">Status : Scanning</p>
            <br />
            <br />
            <input
              className="input-search"
              type="text"
              placeholder="Search ..."
            />
            {/* <button className="btn-search"></button> */}
            <div className="scroll scrollable-element">
              <table class="table th ">
                <thead>
                  <tr>
                    <th className="theader">Severity</th>
                    <th className="theader">IP</th>
                    <th className="theader">OS</th>
                    <th className="theader">Manufacture</th>
                  </tr>
                </thead>

                <tbody>{this.renderNetAddress()}</tbody>
              </table>
            </div>
          </div>
          <div>
            {" "}
            <div className="a1">
              <p className="a1-t1">Executed module</p>
              <div className="scroll">
                {this.renderCollapsibles()}
                <br />
                {this.renderCollapsibles()}
              </div>
            </div>
          </div>
          <div>
            <p className="p-a size">IP port info : '/{this.state.portno}'</p>
            <p className="p-b p-b-c">Total port open : 09</p>
            <div className="block scroll">
              <table class="table-port">
                <thead>
                  <tr>
                    <th className="ths">Severity</th>
                    <th className="ths">Port No</th>
                    <th className="ths">Cv No.</th>
                    <th className="ths">Services</th>
                    <th className="ths">Version</th>
                  </tr>
                </thead>
                <tbody>{this.renderTableData()}</tbody>
              </table>
            </div>
          </div>
          <div>
            {" "}
            <div className="a1">
              <p className="a1-t1">Module Output</p>
              <div className="scroll">
                {this.renderInfo()}
                <br />
                {this.renderInfo()}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  renderInfo(m_address) {
    return (
      <div>
        <InfoGather details={m_address}></InfoGather>
      </div>
    );
  }
  renderNetAddress() {
    return this.datas.network.map((address, index) => {
      const { id, serverty, ip, os, manufacture } = address; //destructuring
      return (
        <tr key={id}>
          <td>{serverty}</td>
          <td onClick={(e) => this.renderInfo({ ip, os, manufacture })}>
            {ip}
          </td>
          <td>{os}</td>
          <td>{manufacture}</td>
        </tr>
      );
    });
  }
  renderCollapsibles() {
    return (
      <div>
        <Collapsible title="Information Gathering">
          <div className="collapsible-detail">
            <p>Hostname</p>
            <p>Mac Information</p>
            <p>Port Discovery</p>
            <p>Service Detection</p>
            <p>OS Detection</p>
          </div>
        </Collapsible>
        <Collapsible title="Exploitation">
          <div className="collapsible-detail">
            <p>Open Ports and Services</p>
          </div>
        </Collapsible>
        <Collapsible title="Vulnerability Validation"></Collapsible>
        <Collapsible title="Vulnerability Analysis"></Collapsible>
        <Collapsible title="Reporting"></Collapsible>
      </div>
    );
  }
  renderTableData() {
    return this.tabel2.port.map((student, index) => {
      const { id, serverity, cvNo, portno, services, version } = student; //destructuring
      return (
        <tr key={id}>
          <td className="ths">{serverity}</td>
          <td className="ths">{cvNo}</td>
          <td className="ths">{portno}</td>
          <td className="ths">{services}</td>
          <td className="ths">{version}</td>
        </tr>
      );
    });
  }
}

export default Improve;
