import React, { Component } from 'react';

class InfoGather extends Component {
    // constructor(props)
    // {
    //     super(props);
    // }
    state = {  }
    ip="192.168.1.1";
    os="Windows";
    manufacture="Microsoft"
    render() { 
        return ( <div>
            <h1 className="ip-title">Network Infomation Gathering</h1>
            <h1 className="ip-display">Information Gathering for {this.ip}</h1>
            <div className="ip-os-details">
                <h1 className="ip-title-margin">Operating System</h1>
                <ul>
                    <li className="ip-list">Name<p className="ip-list-details">{this.os}</p></li>
                    <li className="ip-list">Build Number<p className="ip-list-details">3736</p></li>
                    <li className="ip-list">Manufacturer<p className="ip-list-details">{this.manufacture}</p></li>
                    
                </ul>
            </div>
            <h1 className="ip-title-margin">Port Details</h1>
{/*             <ul>
            <li className="ip-list">88<p className="ip-list-details">xampp</p> <p className="ip-list-details">http</p></li>
            <li className="ip-list">53<p className="ip-list-details">RFC 1034-1035</p> <p className="ip-list-details">dns</p></li>
            <li className="ip-list">513<p className="ip-list-details">login</p> <p className="ip-list-details">6795</p></li>
            </ul> */}

            <table className="ip-ports-table" >
                <tr>
                    <td className="ip-ports-td">88</td>
                    <td className="ip-ports-td">xampp</td>
                    <td className="ip-ports-td">https</td>
                </tr>
                <tr>
                    <td className="ip-ports-td">53</td>
                    <td className="ip-ports-td">RFC 1034-1035</td>
                    <td className="ip-ports-td">dns</td>
                </tr>
                <tr>
                    <td className="ip-ports-td">513</td>
                    <td className="ip-ports-td">login</td>
                    <td className="ip-ports-td">6795</td>
                </tr>
            </table>
            </div> );
    }
}
 
export default InfoGather;