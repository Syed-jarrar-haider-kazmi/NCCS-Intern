import React, { Component } from "react";
//import { ReactDOM } from "react";
import "./main.css";

export class Mains extends Component {
  state = {
    col: 0,
    row: 0,
    order: false,
  };

  temp2 = [
    {
      _id: 1,
      sno: 120,
      serverity: "5545",
      cvNo: "219",
      portno: "6407",
      services: "RFC 1034",
      version: "http",
    },
    {
      _id: 2,
      sno: 124,
      serverity: "5855",
      cvNo: "09",
      portno: "6667",
      services: "login",
      version: "dns",
    },
    {
      _id: 3,
      sno: 128,
      serverity: "123",
      cvNo: "19",
      portno: "1513",
      services: "ic",
      version: "TCP",
    },
    {
      _id: 4,
      sno: 130,
      serverity: "555",
      cvNo: "129",
      portno: "607",
      services: "RFC 1034",
      version: "http",
    },
    {
      _id: 5,
      sno: 134,
      serverity: "555",
      cvNo: "09",
      portno: "667",
      services: "login",
      version: "dns",
    },
    {
      _id: 6,
      sno: 138,
      serverity: "123",
      cvNo: "119",
      portno: "5113",
      services: "ic",
      version: "TCP",
    },
  ]; //table data

  tabel2 = [
    {
      _id: 1,
      sno: 120,
      serverity: "5545",
      cvNo: "219",
      portno: "6407",
      services: "RFC 1034",
      version: "http",
    },
    {
      _id: 2,
      sno: 124,
      serverity: "5855",
      cvNo: "09",
      portno: "6667",
      services: "login",
      version: "dns",
    },
    {
      _id: 3,
      sno: 128,
      serverity: "123",
      cvNo: "19",
      portno: "1513",
      services: "ic",
      version: "TCP",
    },
    {
      _id: 4,
      sno: 130,
      serverity: "555",
      cvNo: "129",
      portno: "607",
      services: "RFC 1034",
      version: "http",
    },
    {
      _id: 5,
      sno: 134,
      serverity: "555",
      cvNo: "09",
      portno: "667",
      services: "login",
      version: "dns",
    },
    {
      _id: 6,
      sno: 138,
      serverity: "123",
      cvNo: "119",
      portno: "5113",
      services: "ic",
      version: "TCP",
    },
  ];

  renderSearch = () => {
    var temp = [];
    this.setState((this.tabel2 = this.temp2));
    var title = this.title.value;

    for (let i = 0; i < this.tabel2.length; i++) {
      if (title === this.tabel2[i].cvNo) {
        // console.log("matched");
        temp.push(this.tabel2[i]);
       // this.setState((this.tabel2 = temp));
      }
    }
    if (temp.length > 0) {
      this.setState((this.tabel2 = temp));
    }
    else if (title.length <= 0) {
      this.setState((this.tabel2 = this.temp2));
    }
  };
  handleChange = (e) => {
    // console.log(e.target.value);
    this.renderSearch();
  };

  renderSort = (event, sortby) => {
    function compare(a, b) {
      // let  order = true;
      const versionA = a.version.toUpperCase();
      const versionB = b.version.toUpperCase();

      let comparison = 0;
      if (versionA > versionB) {
        comparison = 1;
      } else if (versionA < versionB) {
        comparison = -1;
      }
      return comparison;
      //return ((order === true) ? (comparison * -1) : comparison );
    }

    console.log(this.tabel2.sort(compare));
    this.setState({ table2: this.tabel2.sort(compare) });
  };

  //rendering table
  renderTableData() {
    return this.tabel2.map((student, index) => {
      const { id, sno, serverity, cvNo, portno, services, version } = student; //destructuring
      return (
        <tr key={id}>
          <td>{sno}</td>
          <td>{serverity}</td>
          <td>{cvNo}</td>
          <td>{portno}</td>
          <td>{services}</td>
          <td>{version}</td>
        </tr>
      );
    });
  }

  render() {
    return (
      <React.Fragment>
        <main className="mains">
          <input
            type="text"
            placeholder="Search Port No"
            className="input-search "
            ref={(c) => (this.title = c)}
            name="title"
            onChange={this.handleChange}
          ></input>
          {/* <button
            id="search"
            className="btn btn-search"
            onClick={this.renderSearch}
          >
            Search
          </button> */}

          <table
            cellSpacing={this.state.col}
            cellPadding={this.state.row}
            className="tables"
          >
            <thead onClick={(e) => this.renderSort(e, "portno")}>
              <tr>
                <th className="tables-th">S.No </th>
                <th className="tables-th">Severity</th>
                <th className="tables-th">Port No</th>
                <th className="tables-th">Cv No.</th>
                <th className="tables-th">Services</th>
                <th className="tables-th">Version</th>
              </tr>
            </thead>

            <tbody className="tables-tb">{this.renderTableData()}</tbody>
          </table>
        </main>
      </React.Fragment>
    );
  }
}

export default Mains;
