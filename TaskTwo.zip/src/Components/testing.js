import React, { Component } from "react";

// import { Input } from "semantic-ui-react";
import ReactTable from "react-table-6";
// import "react-table-6/react-table.css";
import "./testing.css";

export class Test extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addBorder: null,
      data: [
        {
          _id: 1,
          sno: 120,
          serverity: "5545",
          cvNo: "219",
          portno: "6407",
          services: "RFC 1034",
          version: "http",
        },
        {
          _id: 2,
          sno: 124,
          serverity: "5855",
          cvNo: "09",
          portno: "6667",
          services: "login",
          version: "dns",
        },
        {
          _id: 3,
          sno: 128,
          serverity: "123",
          cvNo: "19",
          portno: "1513",
          services: "ic",
          version: "TCP",
        },
        {
          _id: 4,
          sno: 130,
          serverity: "555",
          cvNo: "129",
          portno: "607",
          services: "RFC 1034",
          version: "http",
        },
        {
          _id: 5,
          sno: 134,
          serverity: "555",
          cvNo: "09",
          portno: "667",
          services: "login",
          version: "dns",
        },
        {
          _id: 6,
          sno: 138,
          serverity: "123",
          cvNo: "119",
          portno: "5113",
          services: "ic",
          version: "TCP",
        },
        {
          _id: 1,
          sno: 120,
          serverity: "5545",
          cvNo: "219",
          portno: "6407",
          services: "RFC 1034",
          version: "http",
        },
        {
          _id: 2,
          sno: 124,
          serverity: "5855",
          cvNo: "09",
          portno: "6667",
          services: "login",
          version: "dns",
        },
        {
          _id: 3,
          sno: 128,
          serverity: "123",
          cvNo: "19",
          portno: "1513",
          services: "ic",
          version: "TCP",
        },
        {
          _id: 4,
          sno: 130,
          serverity: "555",
          cvNo: "129",
          portno: "607",
          services: "RFC 1034",
          version: "http",
        },
        {
          _id: 5,
          sno: 134,
          serverity: "555",
          cvNo: "09",
          portno: "667",
          services: "login",
          version: "dns",
        },
        {
          _id: 6,
          sno: 138,
          serverity: "123",
          cvNo: "119",
          portno: "5113",
          services: "ic",
          version: "TCP",
        },
      ],

      filteredData: [],
      columns: [],
      searchInput: "",
    };
  }

  componentDidMount() {
    let columns = [
      {
        Header: "Sno",
        accessor: "sno",
        sortable: true,
        show: true,
        displayValue: " S NO",
      },
      {
        Header: "Serverity",
        accessor: "serverity",
        sortable: true,
        show: true,
        displayValue: "Serverity ",
      },
      {
        Header: "CVNo",
        accessor: "cvNo",
        sortable: true,
        show: true,
        displayValue: " CV No ",
      },
      {
        Header: "Portno",
        accessor: "portno",
        sortable: true,
        show: true,
        displayValue: " Portno ",
      },
      {
        Header: "Services",
        accessor: "services",
        sortable: true,
        show: true,
        displayValue: " Services ",
      },
      {
        Header: "Version",
        accessor: "version",
        sortable: true,
        show: true,
        displayValue: " Version ",
      },
    ];
    this.setState({ columns });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput, data } = this.state;
    let filteredData = data.filter((value) => {
      return (
        value.portno.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.portno.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.portno
          .toString()
          .toLowerCase()
          .includes(searchInput.toLowerCase()) ||
        value.version.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.version.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.version
          .toString()
          .toLowerCase()
          .includes(searchInput.toLowerCase())
      );
    });
    this.setState({ filteredData });
  };

  render() {
    let { data, columns, searchInput } = this.state;
    return (
      <div className="">
        <br />
        <input
          name="searchInput"
          value={searchInput || ""}
          onChange={this.handleChange}
          placeholder="Search Port no or Version..."
          className="input-search"
        />
        <br />

        <ReactTable
          data={
            this.state.filteredData && this.state.filteredData.length
              ? this.state.filteredData
              : data
          }
          columns={columns}
          defaultPageSize={8}
          showPaginationBottom={this.state.data.length > 10 ? true : false}
          onResizedChange={(col, e) => {
            const column = col[col.length - 1];
            this.setState({ addBorder: column.id });
          }}
          className=" -highlight -striped -size"
        />
      </div>
    );
  }
}

export default Test;
