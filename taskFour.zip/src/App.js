import "./App.css";

import chartDisp from "./Components/center.jsx";

function App() {
  return chartDisp();
}

export default App;
