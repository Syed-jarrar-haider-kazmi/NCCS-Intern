import "./Styles.css";
import React from "react";
import { Doughnut } from "react-chartjs-2";

const state = {
  labels: ["Critical", "High", "Median", "Low", "info"],
  datasets: [
    {
      label: "Risks",
      backgroundColor: ["#B21F00", "#C9DE00", "#2FDE00", "#00A6B4", "#6800B4"],
      hoverBackgroundColor: [
        "#501800",
        "#4B5000",
        "#175000",
        "#003350",
        "#35014F",
      ],
      borderWidth: 1,
      data: [65, 59, 80, 81, 56],
    },
  ],
};

function chartDisp() {
  return (
    <div className="center">
      <p className="center-text">IP : 192.168.15.68</p>
      <Doughnut
        className="center-pie"
        data={state}
        style={{ height: "400px", width: "400px" }}
        options={{
          title: {
            display: false,
            text: "Software Risks",
            fontSize: 6,
          },
          legend: {
            display: false,
            position: "right",
          },
        }}
      />
    </div>
  );
}

export default chartDisp;
