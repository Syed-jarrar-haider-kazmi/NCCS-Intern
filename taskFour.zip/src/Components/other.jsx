import * as React from "react";

import { Circle as CircleGeometry } from "@progress/kendo-drawing/geometry";
import { Layout, Text } from "@progress/kendo-drawing";
import {
  Chart,
  ChartLegend,
  ChartSeries,
  ChartSeriesItem,
  ChartSeriesLabels,
} from "@progress/kendo-react-charts";
import data from "./datas.json";
let center;
let radius;

const labelContent = (e) => e.category;

const visualHandler = (e) => {
  center = e.center;
  radius = e.innerRadius;
  return e.createVisual();
};

const onRender = (e) => {
  const circleGeometry = new CircleGeometry(center, radius);
  const bbox = circleGeometry.bbox();
  const heading = new Text("22.5%", [0, 0], {
    font: "28px Verdana,Arial,sans-serif",
  });
  const line1 = new Text("of which", [0, 0], {
    font: "16px Verdana,Arial,sans-serif",
  });
  const line2 = new Text("renewables", [0, 0], {
    font: "16px Verdana,Arial,sans-serif",
  });
  const layout = new Layout(bbox, {
    alignContent: "center",
    alignItems: "center",
    justifyContent: "center",
    spacing: 5,
  });
  layout.append(heading, line1, line2);
  layout.reflow();
  e.target.surface.draw(layout);
};

const ChartContainer = () => (
  <Chart onRender={onRender}>
    <ChartSeries>
      <ChartSeriesItem
        type="donut"
        data={data}
        categoryField="kind"
        field="share"
        visual={visualHandler}
      >
        <ChartSeriesLabels
          color="#fff"
          background="none"
          content={labelContent}
        />
      </ChartSeriesItem>
    </ChartSeries>
    <ChartLegend visible={false} />
  </Chart>
);

export default ChartContainer;
